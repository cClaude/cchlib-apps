package com.googlecode.cchlib.apps.sample2;

import com.googlecode.cchlib.swing.DialogHelper;

/**
 * com.googlecode.cchlib.apps.sample2.Sample2
 */
public class Sample2
{
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        DialogHelper.showMessageExceptionDialog( "OK", new Exception( "OK") );
    }

}
